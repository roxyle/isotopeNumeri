var options = { searchable: true };
NiceSelect.bind(document.getElementById("searchable-select"), options);

var elem = document.querySelector(".grid");

var iso = new Isotope(".grid", {
  itemSelector: ".grid-item",
  layoutMode: "fitRows",
});



let selettore2 = document.getElementById("searchable-select");
selettore2.onchange = function () {
  var selected = [];
  let valori;  
  for (var option of selettore2.options) {
    if (option.selected) {
      selected.push(option.value);
    }
     valori = selected.join('');
     
  }
  console.log(valori);
    iso.arrange({
     filter: valori
    });
};

